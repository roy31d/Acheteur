var config = {
	paths: {
		'magepow/elevatezoom'	: 'Magepow_Productzoom/js/plugins/jquery.elevatezoom',
	},
	shim: {
		'magepow/elevatezoom': {
			deps: ['jquery']
		}
	}
};
